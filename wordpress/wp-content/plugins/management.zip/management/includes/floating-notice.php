<?php

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Load Bootstrap 5 on the front-end (only if not already loaded by the theme).
 * Uses a distinct handle so it won't double-load if the theme already has its own.
 */
function hr_enqueue_bootstrap_assets()
{
    if (! wp_style_is('bootstrap', 'registered') && ! wp_style_is('bootstrap', 'enqueued')) {
        wp_enqueue_style(
            'hr-bootstrap-cdn',
            'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css',
            array(),
            '5.3.3'
        );
    }
    if (! wp_script_is('bootstrap', 'registered') && ! wp_script_is('bootstrap', 'enqueued')) {
        wp_enqueue_script(
            'hr-bootstrap-cdn-js',
            'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js',
            array(),
            '5.3.3',
            true
        );
    }
}

/**
 * [hr_notices_floating]
 *
 * A fixed-position Bootstrap card that sticks to the side of the screen
 * (e.g. homepage), showing the latest notices, with a close (X) button
 * on each individual notice. Nothing is remembered across page loads -
 * every refresh shows all notices again.
 *
 * Attributes:
 *   limit    (int)    default 5     -> 0 = show all
 *   position (string) default "right" -> right | left
 *   title    (string) default "Notices & Announcements"
 */
function hr_notices_floating_shortcode($atts)
{
    $atts = shortcode_atts(
        array(
            'limit'    => 5,
            'position' => 'right',
            'title'    => 'Notices & Announcements',
        ),
        $atts,
        'hr_notices_floating'
    );

    hr_enqueue_bootstrap_assets();

    global $wpdb;
    $notice_table = $wpdb->prefix . 'hr_notices';
    $limit        = intval($atts['limit']);
    $limit_sql    = $limit > 0 ? 'LIMIT ' . $limit : '';
    $position     = $atts['position'] === 'left' ? 'left' : 'right';

    $notices = $wpdb->get_results(
        "SELECT * FROM {$notice_table}
         WHERE expiry_date IS NULL OR expiry_date >= CURDATE()
         ORDER BY FIELD(priority,'high','normal','low'), created_at DESC
         {$limit_sql}"
    );

    static $instance = 0;
    $instance++;
    $card_id = 'hr-floating-notice-' . $instance;

    ob_start();
    ?>
    <div id="<?php echo esc_attr($card_id); ?>"
         class="card shadow hr-floating-card hr-floating-<?php echo esc_attr($position); ?>">
        <div class="card-header d-flex align-items-center justify-content-between bg-primary text-white py-2">
            <strong class="small mb-0"><?php echo esc_html($atts['title']); ?></strong>
            <button type="button" class="btn-close btn-close-white hr-floating-close" aria-label="Close"></button>
        </div>
        <div class="card-body p-0" style="max-height:320px; overflow-y:auto;">
            <?php if ($notices) : ?>
                <ul class="list-group list-group-flush">
                    <?php foreach ($notices as $notice) :
                        $priority = $notice->priority;
                        $badge_class = $priority === 'high' ? 'bg-danger' : ($priority === 'low' ? 'bg-secondary' : 'bg-primary');
                        $date = date('d M', strtotime($notice->created_at));
                        $excerpt = wp_trim_words(wp_strip_all_tags($notice->content), 14);
                        ?>
                        <li class="list-group-item hr-floating-item">
                            <button type="button" class="btn-close hr-floating-item-close" aria-label="Dismiss this notice"></button>
                            <div class="d-flex justify-content-between align-items-start pe-3">
                                <span class="fw-semibold small"><?php echo esc_html($notice->title); ?></span>
                                <span class="badge <?php echo esc_attr($badge_class); ?> ms-2"><?php echo esc_html($date); ?></span>
                            </div>
                            <?php if ($excerpt) : ?>
                                <p class="text-muted small mb-0 mt-1 pe-3"><?php echo esc_html($excerpt); ?></p>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else : ?>
                <p class="text-muted small p-3 mb-0">No notices right now.</p>
            <?php endif; ?>
        </div>
    </div>

    <style>
        .hr-floating-card {
            position: fixed;
            bottom: 24px;
            width: 300px;
            max-width: 85vw;
            z-index: 1050;
            border: none;
            border-radius: 10px;
            overflow: hidden;
        }
        .hr-floating-right { right: 24px; }
        .hr-floating-left  { left: 24px; }
        .hr-floating-item { position: relative; }
        .hr-floating-item-close {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 10px;
        }
        @media (max-width: 576px) {
            .hr-floating-card { width: calc(100vw - 32px); bottom: 12px; }
            .hr-floating-right { right: 16px; }
            .hr-floating-left  { left: 16px; }
        }
    </style>

    <script>
    (function () {
        var card = document.getElementById('<?php echo esc_js($card_id); ?>');
        if (!card) { return; }

        // Always show fresh on every page load/refresh - nothing is remembered.
        card.style.display = 'block';

        var body = card.querySelector('.card-body');

        // Whole-card close button (in the header).
        var closeBtn = card.querySelector('.hr-floating-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', function () {
                card.style.display = 'none';
            });
        }

        // Per-notice close buttons - removes just that one item.
        var itemButtons = card.querySelectorAll('.hr-floating-item-close');
        itemButtons.forEach(function (btn) {
            btn.addEventListener('click', function () {
                var item = btn.closest('.hr-floating-item');
                if (item) {
                    item.remove();
                }
                // If no notices are left, hide the whole card.
                if (body && !body.querySelector('.hr-floating-item')) {
                    card.style.display = 'none';
                }
            });
        });
    })();
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('hr_notices_floating', 'hr_notices_floating_shortcode');
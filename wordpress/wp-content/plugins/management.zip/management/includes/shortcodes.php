<?php

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Shared inline CSS for all HR frontend shortcodes (printed once per page load).
 */
function hr_frontend_shortcode_styles()
{
    static $printed = false;
    if ($printed) {
        return;
    }
    $printed = true;
    ?>
    <style>
        .hrfe-wrap { --hrfe-primary:#2271b1; --hrfe-border:#e2e4e7; font-family:inherit; }
        .hrfe-section { margin-bottom: 10px; }
        .hrfe-section h3 {
            font-size: 20px;
            margin: 0 0 16px;
            padding-bottom: 8px;
            border-bottom: 2px solid var(--hrfe-primary);
            display: inline-block;
        }
        .hrfe-emp-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
            gap: 18px;
        }
        .hrfe-emp-card {
            background: #fff;
            border: 1px solid var(--hrfe-border);
            border-radius: 8px;
            padding: 18px;
            text-align: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            transition: transform .15s ease, box-shadow .15s ease;
        }
        .hrfe-emp-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 16px rgba(0,0,0,0.08);
        }
        .hrfe-emp-photo {
            width: 84px;
            height: 84px;
            border-radius: 50%;
            object-fit: cover;
            margin: 0 auto 12px;
            display: block;
            border: 3px solid #f0f2f5;
        }
        .hrfe-emp-name { font-weight: 600; font-size: 15px; margin-bottom: 2px; color:#1d2327; }
        .hrfe-emp-designation { font-size: 13px; color: var(--hrfe-primary); margin-bottom: 4px; }
        .hrfe-emp-department { font-size: 12px; color: #777; margin-bottom: 8px; }
        .hrfe-emp-contact { font-size: 12px; color: #555; line-height: 1.6; word-break: break-word; }
        .hrfe-badge {
            display: inline-block;
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: .03em;
            padding: 2px 8px;
            border-radius: 10px;
            margin-top: 8px;
        }
        .hrfe-badge-active   { background:#e6f4ea; color:#1e7e34; }
        .hrfe-badge-inactive { background:#fdecea; color:#b32d2e; }
        .hrfe-badge-on_leave { background:#fff8e1; color:#9a6700; }

        .hrfe-notice-list { list-style: none; margin: 0; padding: 0; }
        .hrfe-notice-item {
            display: flex;
            gap: 14px;
            align-items: flex-start;
            background: #fff;
            border: 1px solid var(--hrfe-border);
            border-left: 4px solid var(--hrfe-primary);
            border-radius: 6px;
            padding: 14px 16px;
            margin-bottom: 12px;
        }
        .hrfe-notice-item.priority-high { border-left-color:#d63638; }
        .hrfe-notice-item.priority-normal { border-left-color:#2271b1; }
        .hrfe-notice-item.priority-low { border-left-color:#8c8f94; }
        .hrfe-notice-title { font-weight: 600; font-size: 15px; margin: 0 0 4px; color:#1d2327; }
        .hrfe-notice-meta { font-size: 12px; color:#777; margin-bottom: 6px; }
        .hrfe-notice-content { font-size: 13px; color:#444; line-height:1.5; }
        .hrfe-empty { color:#8c8f94; font-style: italic; }
    </style>
    <?php
}

/**
 * Build the employees markup (used by both [hr_employees] and [hr_employees_notices]).
 */
function hr_render_employees_markup($employee_limit = 8, $department_id = 0, $status = 'active', $show_heading = true)
{
    global $wpdb;

    $emp_table   = $wpdb->prefix . 'hr_employees';
    $dept_table  = $wpdb->prefix . 'hr_departments';
    $desig_table = $wpdb->prefix . 'hr_designations';

    $where  = array();
    $params = array();

    if ($status !== 'all') {
        $where[]  = 'e.status = %s';
        $params[] = $status;
    }
    if ($department_id > 0) {
        $where[]  = 'e.department_id = %d';
        $params[] = $department_id;
    }

    $where_sql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
    $limit_sql = $employee_limit > 0 ? 'LIMIT ' . intval($employee_limit) : '';

    $sql = "SELECT e.*, d.name AS department_name, s.name AS designation_name
            FROM {$emp_table} e
            LEFT JOIN {$dept_table} d ON d.id = e.department_id
            LEFT JOIN {$desig_table} s ON s.id = e.designation_id
            {$where_sql}
            ORDER BY e.id DESC
            {$limit_sql}";

    if ($params) {
        $sql = $wpdb->prepare($sql, $params);
    }

    $employees = $wpdb->get_results($sql);

    ob_start();
    ?>
    <div class="hrfe-section">
        <?php if ($show_heading) : ?><h3>Our Team</h3><?php endif; ?>
        <?php if ($employees) : ?>
            <div class="hrfe-emp-grid">
                <?php foreach ($employees as $emp) :
                    $photo = $emp->image ? wp_get_attachment_url($emp->image) : '';
                    if (! $photo) {
                        $photo = 'https://placehold.co/160x160.png?text=' . rawurlencode(substr($emp->name, 0, 1));
                    }
                    $status_class = 'hrfe-badge-' . sanitize_html_class($emp->status);
                    $status_labels = array('active' => 'Active', 'inactive' => 'Inactive', 'on_leave' => 'On Leave');
                    $status_text = isset($status_labels[$emp->status]) ? $status_labels[$emp->status] : ucfirst($emp->status);
                    ?>
                    <div class="hrfe-emp-card">
                        <img class="hrfe-emp-photo" src="<?php echo esc_url($photo); ?>" alt="<?php echo esc_attr($emp->name); ?>">
                        <div class="hrfe-emp-name"><?php echo esc_html($emp->name); ?></div>
                        <?php if ($emp->designation_name) : ?>
                            <div class="hrfe-emp-designation"><?php echo esc_html($emp->designation_name); ?></div>
                        <?php endif; ?>
                        <?php if ($emp->department_name) : ?>
                            <div class="hrfe-emp-department"><?php echo esc_html($emp->department_name); ?></div>
                        <?php endif; ?>
                        <div class="hrfe-emp-contact">
                            <?php if ($emp->email) : ?><?php echo esc_html($emp->email); ?><br><?php endif; ?>
                            <?php if ($emp->phone) : ?><?php echo esc_html($emp->phone); ?><?php endif; ?>
                        </div>
                        <span class="hrfe-badge <?php echo esc_attr($status_class); ?>"><?php echo esc_html($status_text); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else : ?>
            <p class="hrfe-empty">No employees to show yet.</p>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Build the notices markup (used by both [hr_notices] and [hr_employees_notices]).
 */
function hr_render_notices_markup($notice_limit = 5, $show_heading = true)
{
    global $wpdb;

    $notice_table     = $wpdb->prefix . 'hr_notices';
    $notice_limit_sql = $notice_limit > 0 ? 'LIMIT ' . intval($notice_limit) : '';

    $notices = $wpdb->get_results(
        "SELECT * FROM {$notice_table}
         WHERE expiry_date IS NULL OR expiry_date >= CURDATE()
         ORDER BY FIELD(priority,'high','normal','low'), created_at DESC
         {$notice_limit_sql}"
    );

    ob_start();
    ?>
    <div class="hrfe-section">
        <?php if ($show_heading) : ?><h3>Notices &amp; Announcements</h3><?php endif; ?>
        <?php if ($notices) : ?>
            <ul class="hrfe-notice-list">
                <?php foreach ($notices as $notice) :
                    $priority_class = 'priority-' . sanitize_html_class($notice->priority);
                    $date = date('d M, Y', strtotime($notice->created_at));
                    $expiry = $notice->expiry_date ? date('d M, Y', strtotime($notice->expiry_date)) : '';
                    $excerpt = wp_trim_words(wp_strip_all_tags($notice->content), 25);
                    ?>
                    <li class="hrfe-notice-item <?php echo esc_attr($priority_class); ?>">
                        <div>
                            <p class="hrfe-notice-title"><?php echo esc_html($notice->title); ?></p>
                            <p class="hrfe-notice-meta">
                                <?php echo esc_html($date); ?><?php echo $expiry ? ' &middot; Expires ' . esc_html($expiry) : ''; ?>
                            </p>
                            <?php if ($excerpt) : ?>
                                <p class="hrfe-notice-content"><?php echo esc_html($excerpt); ?></p>
                            <?php endif; ?>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else : ?>
            <p class="hrfe-empty">No notices to show right now.</p>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * [hr_employees]
 *
 * Attributes:
 *   limit          (int)    default 8   -> 0 = show all
 *   department_id  (int)    default 0   -> filter by department
 *   status         (string) default "active" -> active | inactive | on_leave | all
 */
function hr_employees_shortcode($atts)
{
    $atts = shortcode_atts(
        array(
            'limit'         => 8,
            'department_id' => 0,
            'status'        => 'active',
        ),
        $atts,
        'hr_employees'
    );

    hr_frontend_shortcode_styles();

    ob_start();
    ?>
    <div class="hrfe-wrap">
        <?php
        echo hr_render_employees_markup(
            intval($atts['limit']),
            intval($atts['department_id']),
            sanitize_text_field($atts['status']),
            true
        );
        ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('hr_employees', 'hr_employees_shortcode');

/**
 * [hr_notices]
 *
 * Attributes:
 *   limit (int) default 5 -> 0 = show all
 */
function hr_notices_shortcode($atts)
{
    $atts = shortcode_atts(
        array(
            'limit' => 5,
        ),
        $atts,
        'hr_notices'
    );

    hr_frontend_shortcode_styles();

    ob_start();
    ?>
    <div class="hrfe-wrap">
        <?php echo hr_render_notices_markup(intval($atts['limit']), true); ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('hr_notices', 'hr_notices_shortcode');


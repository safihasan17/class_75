<?php

if (! defined('ABSPATH')) {
    exit;
}

function hr_dashboard_page()
{
    global $wpdb;

    // ---- Counts from all 5 tables ----
    $departments_count  = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hr_departments");
    $designations_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hr_designations");
    $employees_count    = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hr_employees");
    $notices_count      = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hr_notices");
    $holidays_count     = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}hr_holidays");

    $cards = array(
        array(
            'label' => 'Employees',
            'count' => $employees_count,
            'url'   => admin_url('admin.php?page=hr-employees'),
            'icon'  => 'dashicons-groups',
            'color' => '#2271b1',
        ),
        array(
            'label' => 'Departments',
            'count' => $departments_count,
            'url'   => admin_url('admin.php?page=hr-departments'),
            'icon'  => 'dashicons-building',
            'color' => '#2a9d8f',
        ),
        array(
            'label' => 'Designations',
            'count' => $designations_count,
            'url'   => admin_url('admin.php?page=hr-designations'),
            'icon'  => 'dashicons-id-alt',
            'color' => '#e76f51',
        ),
        array(
            'label' => 'Notices',
            'count' => $notices_count,
            'url'   => admin_url('admin.php?page=hr-notices'),
            'icon'  => 'dashicons-megaphone',
            'color' => '#e9c46a',
        ),
        array(
            'label' => 'Holidays',
            'count' => $holidays_count,
            'url'   => admin_url('admin.php?page=hr-holidays'),
            'icon'  => 'dashicons-calendar-alt',
            'color' => '#9b5de5',
        ),
    );

    // ---- Recent notices & upcoming holidays for the bottom widgets ----
    $recent_notices = $wpdb->get_results(
        "SELECT * FROM {$wpdb->prefix}hr_notices ORDER BY created_at DESC LIMIT 5"
    );

    $upcoming_holidays = $wpdb->get_results(
        "SELECT * FROM {$wpdb->prefix}hr_holidays WHERE holiday_date >= CURDATE() ORDER BY holiday_date ASC LIMIT 5"
    );

    $shortcodes = array(
        array(
            'label' => 'Employees',
            'code'  => '[hr_employees]',
            'desc'  => 'Shows the employee list/grid on the frontend.',
        ),
        array(
            'label' => 'Notices',
            'code'  => '[hr_notices]',
            'desc'  => 'Shows notices &amp; announcements on the frontend.',
        ),
        
    );

    echo "<div class='wrap hr-dashboard-wrap'>";
    echo "<h1 class='wp-heading-inline'>HR Management Dashboard</h1>";
    echo "<p style='color:#646970;margin-top:6px;'>Overview of all HR data. Click any card to open that section.</p>";

    echo "<style>
        .hr-dashboard-wrap { margin-top: 20px; }
        .hr-dashboard-layout {
            display: flex;
            gap: 24px;
            align-items: flex-start;
            margin-top: 20px;
        }
        .hr-dashboard-main { flex: 1; min-width: 0; }
        .hr-dashboard-sidebar {
            width: 300px;
            min-width: 260px;
            position: sticky;
            top: 40px;
        }
        .hr-card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
            gap: 16px;
            margin: 0 0 32px;
        }
        .hr-card {
            display: flex;
            align-items: center;
            gap: 14px;
            background: #fff;
            border: 1px solid #dcdcde;
            border-left: 4px solid var(--hr-color, #2271b1);
            border-radius: 6px;
            padding: 18px 16px;
            text-decoration: none;
            box-shadow: 0 1px 2px rgba(0,0,0,0.04);
            transition: box-shadow .15s ease, transform .15s ease;
        }
        .hr-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.10);
            transform: translateY(-2px);
        }
        .hr-card-icon {
            width: 46px;
            height: 46px;
            min-width: 46px;
            border-radius: 50%;
            background: var(--hr-color, #2271b1);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .hr-card-icon .dashicons {
            color: #fff;
            font-size: 22px;
            width: 22px;
            height: 22px;
        }
        .hr-card-count {
            font-size: 26px;
            font-weight: 600;
            line-height: 1.2;
            color: #1d2327;
        }
        .hr-card-label {
            font-size: 13px;
            color: #646970;
            text-transform: uppercase;
            letter-spacing: .04em;
        }
        .hr-widgets-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 16px;
        }
        .hr-widget {
            background: #fff;
            border: 1px solid #dcdcde;
            border-radius: 6px;
            padding: 16px 20px;
        }
        .hr-widget h2 {
            font-size: 15px;
            margin: 0 0 12px;
            padding-bottom: 10px;
            border-bottom: 1px solid #f0f0f1;
        }
        .hr-widget ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }
        .hr-widget li {
            padding: 8px 0;
            border-bottom: 1px solid #f6f7f7;
            display: flex;
            justify-content: space-between;
            gap: 10px;
            font-size: 13px;
        }
        .hr-widget li:last-child { border-bottom: none; }
        .hr-widget .hr-empty { color: #8c8f94; font-style: italic; }
        .hr-widget a.hr-view-all { font-size: 13px; }

        .hr-shortcode-box {
            background: #fff;
            border: 1px solid #dcdcde;
            border-radius: 6px;
            padding: 18px 18px 20px;
        }
        .hr-shortcode-box h2 {
            font-size: 14px;
            margin: 0 0 6px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .hr-shortcode-box h2 .dashicons { color: #2271b1; }
        .hr-shortcode-box p.desc {
            font-size: 12px;
            color: #646970;
            margin: 0 0 14px;
            line-height: 1.5;
        }
        .hr-shortcode-item {
            margin-bottom: 18px;
            padding-bottom: 16px;
            border-bottom: 1px solid #f0f0f1;
        }
        .hr-shortcode-item:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }
        .hr-shortcode-item-label {
            font-size: 12px;
            font-weight: 600;
            color: #1d2327;
            margin: 0 0 6px;
        }
        .hr-shortcode-item-desc {
            font-size: 11px;
            color: #8c8f94;
            margin: 6px 0 0;
            line-height: 1.5;
        }
        .hr-shortcode-field {
            display: flex;
            gap: 0;
            margin-bottom: 0;
        }
        .hr-shortcode-field input {
            flex: 1;
            font-family: Consolas, Monaco, monospace;
            font-size: 13px;
            background: #f6f7f7;
            border: 1px solid #dcdcde;
            border-right: none;
            border-radius: 4px 0 0 4px;
            padding: 8px 10px;
            color: #1d2327;
        }
        .hr-shortcode-copy-btn {
            border: 1px solid #2271b1;
            background: #2271b1;
            color: #fff;
            border-radius: 0 4px 4px 0;
            padding: 0 14px;
            cursor: pointer;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 4px;
            transition: background .15s ease;
        }
        .hr-shortcode-copy-btn:hover { background: #135e96; }
        .hr-shortcode-copy-btn.copied { background: #1e7e34; border-color: #1e7e34; }
        .hr-shortcode-hint {
            font-size: 11px;
            color: #8c8f94;
        }
    </style>";

    echo "<div class='hr-dashboard-layout'>";

    // =========================================================
    // LEFT: main content (cards + widgets)
    // =========================================================
    echo "<div class='hr-dashboard-main'>";

    echo "<div class='hr-card-grid'>";
    foreach ($cards as $card) {
        echo "<a class='hr-card' style='--hr-color:{$card['color']}' href='" . esc_url($card['url']) . "'>
                <span class='hr-card-icon'><span class='dashicons {$card['icon']}'></span></span>
                <span>
                    <span class='hr-card-count'>" . esc_html($card['count']) . "</span><br/>
                    <span class='hr-card-label'>" . esc_html($card['label']) . "</span>
                </span>
            </a>";
    }
    echo "</div>";

    echo "<div class='hr-widgets-grid'>";

    echo "<div class='hr-widget'>";
    echo "<h2>Recent Notices</h2><ul>";
    if ($recent_notices) {
        foreach ($recent_notices as $notice) {
            $edit_url = admin_url('admin.php?page=hr-notices-edit&id=' . $notice->id);
            $date     = date('d M, Y', strtotime($notice->created_at));
            echo "<li><a href='{$edit_url}'>" . esc_html($notice->title) . "</a><span>" . esc_html($date) . "</span></li>";
        }
    } else {
        echo "<li class='hr-empty'>No notices yet.</li>";
    }
    echo "</ul>";
    echo "<p><a class='hr-view-all' href='" . admin_url('admin.php?page=hr-notices') . "'>View all notices &rarr;</a></p>";
    echo "</div>";

    echo "<div class='hr-widget'>";
    echo "<h2>Upcoming Holidays</h2><ul>";
    if ($upcoming_holidays) {
        foreach ($upcoming_holidays as $holiday) {
            $edit_url = admin_url('admin.php?page=hr-holidays-edit&id=' . $holiday->id);
            $date     = $holiday->holiday_date ? date('d M, Y', strtotime($holiday->holiday_date)) : '—';
            echo "<li><a href='{$edit_url}'>" . esc_html($holiday->name) . "</a><span>" . esc_html($date) . "</span></li>";
        }
    } else {
        echo "<li class='hr-empty'>No upcoming holidays.</li>";
    }
    echo "</ul>";
    echo "<p><a class='hr-view-all' href='" . admin_url('admin.php?page=hr-holidays') . "'>View all holidays &rarr;</a></p>";
    echo "</div>";

    echo "</div>"; // hr-widgets-grid
    echo "</div>"; // hr-dashboard-main

    // =========================================================
    // RIGHT: sidebar with copyable shortcode
    // =========================================================
    echo "<div class='hr-dashboard-sidebar'>";
    echo "<div class='hr-shortcode-box'>";
    echo "<h2><span class='dashicons dashicons-shortcode'></span> Frontend Shortcodes</h2>";
    echo "<p class='desc'>Paste these into any page or post to show data on your website.</p>";

    foreach ($shortcodes as $i => $sc) {
        $input_id = 'hr-shortcode-input-' . $i;
        $btn_id   = 'hr-shortcode-copy-btn-' . $i;
        $label_id = 'hr-shortcode-copy-label-' . $i;

        echo "<div class='hr-shortcode-item'>";
        echo "<p class='hr-shortcode-item-label'>" . esc_html($sc['label']) . "</p>";
        echo "<div class='hr-shortcode-field'>";
        echo "<input type='text' class='hr-shortcode-input' id='{$input_id}' readonly value='" . esc_attr($sc['code']) . "' onclick='this.select();'>";
        echo "<button type='button' class='hr-shortcode-copy-btn' data-input='{$input_id}' data-label='{$label_id}' id='{$btn_id}'>
                <span class='dashicons dashicons-clipboard'></span><span id='{$label_id}'>Copy</span>
              </button>";
        echo "</div>";
        echo "<p class='hr-shortcode-item-desc'>" . $sc['desc'] . "</p>";
        echo "</div>";
    }

    echo "</div>"; // hr-shortcode-box
    echo "</div>"; // hr-dashboard-sidebar

    echo "</div>"; // hr-dashboard-layout
    echo "</div>"; // wrap

    ?>
    <script>
    (function () {
        var buttons = document.querySelectorAll('.hr-shortcode-copy-btn');

        buttons.forEach(function (btn) {
            var input = document.getElementById(btn.getAttribute('data-input'));
            var label = document.getElementById(btn.getAttribute('data-label'));
            if (!input || !label) { return; }

            btn.addEventListener('click', function () {
                var resetLabel = function () {
                    setTimeout(function () {
                        label.textContent = 'Copy';
                        btn.classList.remove('copied');
                    }, 1500);
                };

                var markCopied = function () {
                    label.textContent = 'Copied!';
                    btn.classList.add('copied');
                    resetLabel();
                };

                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(input.value).then(markCopied, function () {
                        input.select();
                        document.execCommand('copy');
                        markCopied();
                    });
                } else {
                    input.select();
                    document.execCommand('copy');
                    markCopied();
                }
            });
        });
    })();
    </script>
    <?php
}

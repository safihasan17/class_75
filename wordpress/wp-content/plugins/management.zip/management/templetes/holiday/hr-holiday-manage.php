<?php


    global $wpdb;
    $table_name = $wpdb->prefix . 'hr_holidays';

    // Handle delete
    if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'delete') {
        $id = intval($_GET['id']);
        if (isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'delete_holiday_' . $id)) {
            $wpdb->delete($table_name, array('id' => $id));
            echo "<div class='notice notice-success is-dismissible'><p>Holiday deleted successfully.</p></div>";
        }
    }

    $holidays = $wpdb->get_results("SELECT * FROM $table_name ORDER BY holiday_date ASC");

    echo "<div class='wrap'>";
    echo "<h1 class='wp-heading-inline'>Holidays</h1>";
    echo "<a href='" . admin_url('admin.php?page=hr-holidays-add') . "' class='page-title-action'>Add New</a>";

    echo "
    <table class='wp-list-table widefat fixed striped table-view-list tags'>
	<thead>
	<tr>
		<th scope='col' class='manage-column column-name column-primary'>Name</th>
		<th scope='col' class='manage-column'>Holiday Date</th>
		<th scope='col' class='manage-column'>Type</th>
		<th scope='col' class='manage-column'>Created At</th>
		<th scope='col' class='manage-column'>Actions</th>
	</tr>
	</thead>
	<tbody id='the-list'>";

    if ($holidays) {
        foreach ($holidays as $holiday) {
            $edit_url   = admin_url('admin.php?page=hr-holidays-edit&id=' . $holiday->id);
            $delete_url = wp_nonce_url(
                admin_url('admin.php?page=hr-holidays&action=delete&id=' . $holiday->id),
                'delete_holiday_' . $holiday->id
            );

            $type_label    = ucfirst($holiday->holiday_type);
            $holiday_date  = $holiday->holiday_date ? date('d M, Y', strtotime($holiday->holiday_date)) : '—';
            $created_at    = date('d M, Y h:i A', strtotime($holiday->created_at));

            echo "
            <tr id='holiday-{$holiday->id}'>
                <td class='name column-name has-row-actions column-primary' data-colname='Name'>
                    <strong><a class='row-title' href='{$edit_url}'>" . esc_html($holiday->name) . "</a></strong>
                </td>
                <td data-colname='Holiday Date'>" . esc_html($holiday_date) . "</td>
                <td data-colname='Type'>" . esc_html($type_label) . "</td>
                <td data-colname='Created At'>" . esc_html($created_at) . "</td>
                <td>
                <div class=''>
                        <span class='edit'><a href='{$edit_url}'>Edit</a> | </span>
                        <span class='delete'><a href='{$delete_url}' onclick=\"return confirm('Are you sure you want to delete this holiday?');\" style='color:#b32d2e;'>Delete</a></span>
                    </div>
                </td>
            </tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No holidays found yet.</td></tr>";
    }

    echo "
	</tbody>
	</table>
    </div>";


?>

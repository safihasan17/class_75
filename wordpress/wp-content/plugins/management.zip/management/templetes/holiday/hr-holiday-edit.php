<?php


    global $wpdb;
    $table_name = $wpdb->prefix . 'hr_holidays';
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    $holiday = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));

    if (! $holiday) {
        echo "<div class='wrap'><p>Holiday not found.</p></div>";
        return;
    }

    // Handle form submission
    if (isset($_POST['submit']) && isset($_POST['hr_holiday_nonce']) && wp_verify_nonce($_POST['hr_holiday_nonce'], 'edit_holiday_' . $id)) {
        $name         = sanitize_text_field($_POST['name']);
        $holiday_date = !empty($_POST['holiday_date']) ? sanitize_text_field($_POST['holiday_date']) : null;
        $holiday_type = in_array($_POST['holiday_type'], array('national', 'company', 'optional'), true) ? $_POST['holiday_type'] : 'company';

        $wpdb->update(
            $table_name,
            array(
                'name'         => $name,
                'holiday_date' => $holiday_date,
                'holiday_type' => $holiday_type,
            ),
            array('id' => $id)
        );

        echo "<script>window.location.href = '" . admin_url('admin.php?page=hr-holidays') . "';</script>";
        return;
    }

    $created_at = date('d M, Y h:i A', strtotime($holiday->created_at));

    echo "
    <div class='form-wrap'>
    <h2>Edit Holiday</h2>
    <form id='editholiday' method='post'>
        " . wp_nonce_field('edit_holiday_' . $id, 'hr_holiday_nonce', true, false) . "
        <div class='form-field form-required term-name-wrap'>
            <label for='name'>Name</label>
            <input name='name' id='name' type='text' value='" . esc_attr($holiday->name) . "' size='40' required>
        </div>
        <div class='form-field term-slug-wrap'>
            <label for='holiday_date'>Holiday Date</label>
            <input name='holiday_date' id='holiday_date' type='date' value='" . esc_attr($holiday->holiday_date) . "'>
        </div>
        <div class='form-field term-slug-wrap'>
            <label for='holiday_type'>Holiday Type</label>
            <select name='holiday_type' id='holiday_type'>
                <option value='national' " . selected($holiday->holiday_type, 'national', false) . ">National</option>
                <option value='company' " . selected($holiday->holiday_type, 'company', false) . ">Company</option>
                <option value='optional' " . selected($holiday->holiday_type, 'optional', false) . ">Optional</option>
            </select>
        </div>
        <div class='form-field'>
            <label>Created At</label>
            <p><strong>" . esc_html($created_at) . "</strong></p>
        </div>
        <p class='submit'>
            <input type='submit' name='submit' id='submit' class='button button-primary' value='Update Holiday'>
        </p>
    </form>
    </div>
    ";


?>

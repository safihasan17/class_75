<?php


    if (isset($_POST['submit']) && isset($_POST['hr_holiday_nonce']) && wp_verify_nonce($_POST['hr_holiday_nonce'], 'add_holiday')) {

        global $wpdb;
        $table = $wpdb->prefix . 'hr_holidays';

        $name         = sanitize_text_field($_POST['name']);
        $holiday_date = !empty($_POST['holiday_date']) ? sanitize_text_field($_POST['holiday_date']) : null;
        $holiday_type = in_array($_POST['holiday_type'], array('national', 'company', 'optional'), true) ? $_POST['holiday_type'] : 'company';

        $wpdb->insert(
            $table,
            array(
                'name'         => $name,
                'holiday_date' => $holiday_date,
                'holiday_type' => $holiday_type,
            )
        );

        $insert_id = $wpdb->insert_id;
        if ($insert_id) {
            echo '<div class="notice notice-success is-dismissible">
          <p> Holiday saved successfully </p>
        </div>';
        } else {
            echo '<div class="notice notice-error is-dismissible">
          <p> Data not inserted </p>
        </div>';
        }
    };

    echo "
    <div class='form-wrap'>
<h2>Add Holiday</h2>
<form method='post' class='validate'>
    " . wp_nonce_field('add_holiday', 'hr_holiday_nonce', true, false) . "

<div class='form-field term-name-wrap'>
    <label>Name</label>
    <input name='name' type='text' value='' size='40' aria-required='true' aria-describedby='name-description' required>
</div>

<div class='form-field term-slug-wrap'>
    <label>Holiday Date</label>
    <input name='holiday_date' type='date' value=''>
</div>

<div class='form-field term-slug-wrap'>
    <label>Holiday Type</label>
    <select name='holiday_type'>
        <option value='national'>National</option>
        <option value='company' selected>Company</option>
        <option value='optional'>Optional</option>
    </select>
</div>

<p class='submit'>
    <input type='submit' name='submit' id='submit' class='button button-primary' value='Add Holiday'>
    <span class='spinner'></span>
</p>
</form>
</div>
";

?>

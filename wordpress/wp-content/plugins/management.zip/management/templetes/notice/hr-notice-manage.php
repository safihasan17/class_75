<?php


    global $wpdb;
    $table_name = $wpdb->prefix . 'hr_notices';

    // Handle delete
    if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'delete') {
        $id = intval($_GET['id']);
        if (isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'delete_notice_' . $id)) {
            $wpdb->delete($table_name, array('id' => $id));
            echo "<div class='notice notice-success is-dismissible'><p>Notice deleted successfully.</p></div>";
        }
    }

    $notices = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");

    echo "<div class='wrap'>";
    echo "<h1 class='wp-heading-inline'>Notices</h1>";
    echo "<a href='" . admin_url('admin.php?page=hr-notices-add') . "' class='page-title-action'>Add New</a>";

    echo "
    <table class='wp-list-table widefat fixed striped table-view-list tags'>
	<thead>
	<tr>
		<th scope='col' class='manage-column column-name column-primary'>Title</th>
		<th scope='col' class='manage-column'>Priority</th>
		<th scope='col' class='manage-column'>Expiry Date</th>
		<th scope='col' class='manage-column'>Created At</th>
		<th scope='col' class='manage-column'>Actions</th>
	</tr>
	</thead>
	<tbody id='the-list'>";

    if ($notices) {
        foreach ($notices as $notice) {
            $edit_url   = admin_url('admin.php?page=hr-notices-edit&id=' . $notice->id);
            $delete_url = wp_nonce_url(
                admin_url('admin.php?page=hr-notices&action=delete&id=' . $notice->id),
                'delete_notice_' . $notice->id
            );

            $priority_label = ucfirst($notice->priority);
            $expiry_date    = $notice->expiry_date ? date('d M, Y', strtotime($notice->expiry_date)) : '—';
            $created_at     = date('d M, Y h:i A', strtotime($notice->created_at));

            echo "
            <tr id='notice-{$notice->id}'>
                <td class='name column-name has-row-actions column-primary' data-colname='Title'>
                    <strong><a class='row-title' href='{$edit_url}'>" . esc_html($notice->title) . "</a></strong>
                </td>
                <td data-colname='Priority'>" . esc_html($priority_label) . "</td>
                <td data-colname='Expiry Date'>" . esc_html($expiry_date) . "</td>
                <td data-colname='Created At'>" . esc_html($created_at) . "</td>
                <td>
                <div class=''>
                        <span class='edit'><a href='{$edit_url}'>Edit</a> | </span>
                        <span class='delete'><a href='{$delete_url}' onclick=\"return confirm('Are you sure you want to delete this notice?');\" style='color:#b32d2e;'>Delete</a></span>
                    </div>
                </td>
            </tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No notices found yet.</td></tr>";
    }

    echo "
	</tbody>
	</table>
    </div>";


?>

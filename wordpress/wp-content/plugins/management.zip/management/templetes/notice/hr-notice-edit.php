<?php


    global $wpdb;
    $table_name = $wpdb->prefix . 'hr_notices';
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    $notice = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));

    if (! $notice) {
        echo "<div class='wrap'><p>Notice not found.</p></div>";
        return;
    }

    // Handle form submission
    if (isset($_POST['submit']) && isset($_POST['hr_notice_nonce']) && wp_verify_nonce($_POST['hr_notice_nonce'], 'edit_notice_' . $id)) {
        $title       = sanitize_text_field($_POST['title']);
        $content     = sanitize_textarea_field($_POST['content']);
        $priority    = in_array($_POST['priority'], array('low', 'normal', 'high'), true) ? $_POST['priority'] : 'normal';
        $expiry_date = !empty($_POST['expiry_date']) ? sanitize_text_field($_POST['expiry_date']) : null;

        $wpdb->update(
            $table_name,
            array(
                'title'       => $title,
                'content'     => $content,
                'priority'    => $priority,
                'expiry_date' => $expiry_date,
            ),
            array('id' => $id)
        );

        echo "<script>window.location.href = '" . admin_url('admin.php?page=hr-notices') . "';</script>";
        return;
    }

    $created_at = date('d M, Y h:i A', strtotime($notice->created_at));

    echo "
    <div class='form-wrap'>
    <h2>Edit Notice</h2>
    <form id='editnotice' method='post'>
        " . wp_nonce_field('edit_notice_' . $id, 'hr_notice_nonce', true, false) . "
        <div class='form-field form-required term-name-wrap'>
            <label for='title'>Title</label>
            <input name='title' id='title' type='text' value='" . esc_attr($notice->title) . "' size='40' required>
        </div>
        <div class='form-field term-description-wrap'>
            <label for='content'>Content</label>
            <textarea name='content' id='content' rows='5' cols='40'>" . esc_textarea($notice->content) . "</textarea>
        </div>
        <div class='form-field term-slug-wrap'>
            <label for='priority'>Priority</label>
            <select name='priority' id='priority'>
                <option value='low' " . selected($notice->priority, 'low', false) . ">Low</option>
                <option value='normal' " . selected($notice->priority, 'normal', false) . ">Normal</option>
                <option value='high' " . selected($notice->priority, 'high', false) . ">High</option>
            </select>
        </div>
        <div class='form-field term-slug-wrap'>
            <label for='expiry_date'>Expiry Date</label>
            <input name='expiry_date' id='expiry_date' type='date' value='" . esc_attr($notice->expiry_date) . "'>
        </div>
        <div class='form-field'>
            <label>Created At</label>
            <p><strong>" . esc_html($created_at) . "</strong></p>
        </div>
        <p class='submit'>
            <input type='submit' name='submit' id='submit' class='button button-primary' value='Update Notice'>
        </p>
    </form>
    </div>
    ";


?>

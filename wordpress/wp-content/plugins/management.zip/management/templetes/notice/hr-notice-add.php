<?php


    if (isset($_POST['submit']) && isset($_POST['hr_notice_nonce']) && wp_verify_nonce($_POST['hr_notice_nonce'], 'add_notice')) {

        global $wpdb;
        $table = $wpdb->prefix . 'hr_notices';

        $title       = sanitize_text_field($_POST['title']);
        $content     = sanitize_textarea_field($_POST['content']);
        $priority    = in_array($_POST['priority'], array('low', 'normal', 'high'), true) ? $_POST['priority'] : 'normal';
        $expiry_date = !empty($_POST['expiry_date']) ? sanitize_text_field($_POST['expiry_date']) : null;

        $wpdb->insert(
            $table,
            array(
                'title'       => $title,
                'content'     => $content,
                'priority'    => $priority,
                'expiry_date' => $expiry_date,
            )
        );

        $insert_id = $wpdb->insert_id;
        if ($insert_id) {
            echo '<div class="notice notice-success is-dismissible">
          <p> Notice saved successfully </p>
        </div>';
        } else {
            echo '<div class="notice notice-error is-dismissible">
          <p> Data not inserted </p>
        </div>';
        }
    };

    echo "
    <div class='form-wrap'>
<h2>Add Notice</h2>
<form method='post' class='validate'>
    " . wp_nonce_field('add_notice', 'hr_notice_nonce', true, false) . "

<div class='form-field term-name-wrap'>
    <label>Title</label>
    <input name='title' type='text' value='' size='40' aria-required='true' aria-describedby='title-description' required>
</div>

<div class='form-field term-description-wrap'>
    <label>Content</label>
    <textarea name='content' rows='5' cols='40'></textarea>
</div>

<div class='form-field term-slug-wrap'>
    <label>Priority</label>
    <select name='priority'>
        <option value='low'>Low</option>
        <option value='normal' selected>Normal</option>
        <option value='high'>High</option>
    </select>
</div>

<div class='form-field term-slug-wrap'>
    <label>Expiry Date</label>
    <input name='expiry_date' type='date' value=''>
</div>

<p class='submit'>
    <input type='submit' name='submit' id='submit' class='button button-primary' value='Add Notice'>
    <span class='spinner'></span>
</p>
</form>
</div>
";

?>

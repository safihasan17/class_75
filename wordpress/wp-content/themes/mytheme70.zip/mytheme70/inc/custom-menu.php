<?php

function mytheme70_custom_menu(){
    // register_nav_menu( 'top-menu', 'primary Menu');
    // register_nav_menu( 'footer-menu-1', 'Footer Menu 1');
    // register_nav_menu( 'footer-menu-2', 'Footer Menu 2');


    // register_nav_menu( 'top-menu', __('primary Menu', 'Mytheme70'));
    // register_nav_menu( 'footer-menu-1', __('Footer Menu 1', 'Mytheme70'));
    // register_nav_menu( 'footer-menu-2', __('Footer Menu 2', 'Mytheme70'));


    register_nav_menus(array(
       'top-menu'      =>  __('primary Menu', 'Mytheme70'),
       'footer-menu-1' =>  __('Footer Menu 1', 'Mytheme70'),
       'footer-menu-2' =>  __('Footer Menu 2', 'Mytheme70'),
    ));
    
}

add_action( 'after_setup_theme' , 'mytheme70_custom_menu');
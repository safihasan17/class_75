<?php

function mytheme_customizer($wp_customize)
{
    //add section

    $wp_customize->add_section(
        'mytheme70_footer_section',
        array(
            'title' => __('Footer Text', 'Mytheme70'),
            'priority' => 4,

        )

    );

    //add seting

    $wp_customize->add_setting(
        'mytheme70_footer_text',
        array(
            'default' => 'copyright &copy; Mytheme70. ALL rights received',
            'section' => 'mytheme70_footer_section'
        )
    );

    // add comtrol

    $wp_customize->add_control(
        'mytheme70_footer_text',
        array(
            'label'   => __('copyright', 'Mytheme70'),
            'section' => 'mytheme70_footer_section',
            'type'    => 'text',
        )
    );




    //add seting additonal onfo

    $wp_customize->add_setting(
        'mytheme70_footer_additional_info',
        array(
            'default' => 'designed by.',
            'section' => 'mytheme70_footer_section'
        )
    );

    // add comtrol additional info

    $wp_customize->add_control(
        'mytheme70_footer_additional_info',
        array(
            'label'   => __('additional_info', 'Mytheme70'),
            'section' => 'mytheme70_footer_section',
            'type'    => 'textarea',
        )
    );



//===================logo======================

    // Add Logo Section
$wp_customize->add_section(
    'mytheme70_logo_section',
    array(
        'title'    => __('Site Logo', 'Mytheme70'),
        'priority' => 3,
    )
);

// Add Logo Setting
$wp_customize->add_setting(
    'mytheme70_logo',
    array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    )
);

// Add Logo Upload Control
$wp_customize->add_control(
    new WP_Customize_Image_Control(
        $wp_customize,
        'mytheme70_logo',
        array(
            'label'    => __('Upload Logo', 'Mytheme70'),
            'section'  => 'mytheme70_logo_section',
            'settings' => 'mytheme70_logo',
        )
    )
);
}

add_action('customize_register', 'mytheme_customizer');

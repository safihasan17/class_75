<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="Untree.co">
	<link rel="shortcut icon" href="favicon.png">

	<meta name="description" content="" />
	<meta name="keywords" content="bootstrap, bootstrap5" />

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600;700&display=swap" rel="stylesheet">


	<link rel="stylesheet" href=" <?php echo get_template_directory_uri(); ?>/assets/fonts/icomoon/style.css">

	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/fonts/flaticon/font/flaticon.css">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

	<link rel="stylesheet" href="assets/css/tiny-slider.css">
	<link rel="stylesheet" href="assets/css/aos.css">
	<link rel="stylesheet" href="assets/css/glightbox.min.css">
	<link rel="stylesheet" href="assets/css/style.css">

	<link rel="stylesheet" href="assets/css/flatpickr.min.css">




	<?php wp_head(); ?>
</head>

<body>

	<div class="site-mobile-menu site-navbar-target">
		<div class="site-mobile-menu-header">
			<div class="site-mobile-menu-close">
				<span class="icofont-close js-menu-toggle"></span>
			</div>
		</div>
		<div class="site-mobile-menu-body">
			<ul class="site-nav-warp"></ul>
		</div>
	</div>

	<nav class="site-nav">
		<div class="container">
			<div class="menu-bg-wrap">
				<div class="site-navigation">
					<div class="row g-0 align-items-center">
						<div class="col-2">
							<div class="site-logo">

								<?php
								$logo = get_theme_mod('mytheme70_logo');

								if (!empty($logo)) : ?>
									<a href="<?php echo esc_url(home_url('/')); ?>">
										<img
											src="<?php echo esc_url($logo); ?>"
											alt="<?php bloginfo('name'); ?>"
											width="180"
											height="60">
									</a>
								<?php else : ?>
									<a href="<?php echo esc_url(home_url('/')); ?>">
										<?php bloginfo('name'); ?>
									</a>
								<?php endif; ?>

							</div>

							<!-- <a href="index.html" class="logo m-0 float-start">Blogy<span class="text-primary">.</span></a> -->
						</div>
						<div class="col-8 text-center">
							<form action="#" class="search-form d-inline-block d-lg-none">
								<input type="text" class="form-control" placeholder="Search...">
								<span class="bi-search"></span>
							</form>

							<ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
								<?php
								wp_nav_menu(array(
									'theme_location' => 'top-menu',
									'menu_class' => 'site-menu',
								));

								?>

							</ul>
						</div>
						<div class="col-2 text-end">
							<a href="#" class="burger ms-auto float-end site-menu-toggle js-menu-toggle d-inline-block d-lg-none light">
								<span></span>
							</a>
							<form action="#" class="search-form d-none d-lg-inline-block">
								<input type="text" class="form-control" placeholder="Search...">
								<span class="bi-search"></span>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</nav>